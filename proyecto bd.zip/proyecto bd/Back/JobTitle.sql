INSERT ALL
INTO JobTitle (id, Title) VALUES (1, 'Actor/Actriz')
INTO JobTitle (id, Title) VALUES (2, 'Director')
INTO JobTitle (id, Title) VALUES (3, 'Productor')
INTO JobTitle (id, Title) VALUES (4, 'Otros')
SELECT 1 FROM dual;
COMMIT;
