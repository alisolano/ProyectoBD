INSERT ALL
INTO Payment(id, Name) VALUES (1, 'Tarjeta de cr�dito/d�bito')
INTO Payment(id, Name) VALUES (2, 'PayPal')
SELECT 1 FROM dual;
COMMIT;
