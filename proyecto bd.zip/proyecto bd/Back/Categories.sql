INSERT INTO category (id, name)
VALUES (1, 'Accion');

INSERT INTO category (id, name)
VALUES (2, 'Aventuras');

INSERT INTO category (id, name)
VALUES (3, 'Ciencia Ficcion');

INSERT INTO category (id, name)
VALUES (4, 'Comedia');

INSERT INTO category (id, name)
VALUES (5, 'No-Ficcion');

INSERT INTO category (id, name)
VALUES (6, 'Drama');

INSERT INTO category (id, name)
VALUES (7, 'Fantas?a');

INSERT INTO category (id, name)
VALUES (8, 'Musical');

INSERT INTO category (id, name)
VALUES (9, 'Suspense');

INSERT INTO category (id, name)
VALUES (10, 'Terror');

INSERT INTO category (id, name)
VALUES (11, 'Documental');

INSERT INTO category (id, name)
VALUES (12, 'Romance');

INSERT INTO category (id, name)
VALUES (13, 'Ficcion');