INSERT INTO State(id, Name, idCountry) 
VALUES (s_state.NEXTVAL, 'Alajuela', 47);

INSERT INTO State(id, Name, idCountry) 
VALUES (s_state.NEXTVAL, 'Heredia', 47);

INSERT INTO State(id, Name, idCountry) 
VALUES (s_state.NEXTVAL, 'Limon', 47);

INSERT INTO State(id, Name, idCountry) 
VALUES (s_state.NEXTVAL, 'Cartago', 47);

INSERT INTO State(id, Name, idCountry) 
VALUES (s_state.NEXTVAL, 'San Jos�', 47);

INSERT INTO State(id, Name, idCountry) 
VALUES (s_state.NEXTVAL, 'Guanacaste', 47);

INSERT INTO State(id, Name, idCountry) 
VALUES (s_state.NEXTVAL, 'Puntarenas', 47);

COMMIT;


