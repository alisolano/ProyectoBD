INSERT ALL 
INTO GENDER (id, Name) VALUES (1, 'Femenino')
INTO GENDER (id, Name) VALUES (2, 'Masculino')
INTO GENDER (id, Name) VALUES (3, 'Otro')
SELECT 1 FROM dual;
COMMIT;
