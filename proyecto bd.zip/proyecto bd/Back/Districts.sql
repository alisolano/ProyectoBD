INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Alajuela', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Atenas', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Grecia', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Guatuso', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Los Chiles', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Naranjo', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Orotina', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Palmares', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Po�s', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'R�o Cuarto', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'San Carlos', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'San Mateo', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'San Ram�n', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Sarch�', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Upala', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Zarcero', 1);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Heredia', 2);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Barva', 2);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Santo Domingo', 2);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Santa B�rbara', 2);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'San Rafael', 2);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'San Isidro', 2);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Bel�n', 2);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Flores', 2);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'San Pablo', 2);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Sarapiqu�', 2);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Gu�cimo', 3);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Lim�n', 3);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Matina', 3);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Pococ�', 3);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Siquirres', 3);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Talamanca', 3);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Cartago', 4);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Alvarado', 4);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'El Guarco', 4);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Jim�nez', 4);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'La Uni�n', 4);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Oreamuno', 4);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Para�so', 4);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Turrialba', 4);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'San Jos�', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Escaz�', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Desamparados', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Puriscal', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Tarraz�', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Aserr�', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Mora', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Goicoechea', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Santa Ana', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Alajuelita', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'V�zquez de Coronado', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Acosta', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Tib�s', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Moravia', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Montes de Oca', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Turrubares', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Dota', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Curridabat', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'P�rez Zeled�n', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Le�n Cort�s Castro', 5);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Liberia', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Nicoya', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Santa Cruz', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Bagaces', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Carrillo', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Ca�as', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Abangares', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Tilar�n', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Nandayure', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'La Cruz', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Hojancha', 6);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Buenos Aires', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Corredores', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Coto Brus', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Esparza', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Garabito', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Golfito', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Montes de Oro', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Monteverde', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Osa', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Parrita', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Puerto Jim�nez', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Puntarenas', 7);

INSERT INTO District(id, Name, idState) 
VALUES (s_district.NEXTVAL, 'Quepos', 7);

COMMIT;